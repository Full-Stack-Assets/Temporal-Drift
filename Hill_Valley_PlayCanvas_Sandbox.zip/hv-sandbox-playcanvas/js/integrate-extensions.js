/**
 * integrate-extensions.js — optional enhancements loaded after core main systems.
 * Import from main or call initExtensions(ctx) with shared context.
 */

import { TouchControls } from './ui/TouchControls.js';
import { FlagPanel } from './ui/FlagPanel.js';
import { SaveStateCompressor } from './storage/SaveStateCompressor.js';
import { bootstrapAmmo, makeStaticCollider } from './vehicle/PhysicsBootstrap.js';
import { AssetPipelineLoader } from './loader/AssetPipelineLoader.js';
import { ChasePhysicsController } from './ai/ChasePhysicsController.js';
import { TemporalPathfinder } from './ai/TemporalPathfinder.js';
import { RadioManager } from './audio/RadioManager.js';
import { AmbientBed } from './audio/AmbientBed.js';
import { ButterflyTriggers } from './temporal/ButterflyTriggers.js';
import * as pc from 'playcanvas';

/**
 * @param {object} ctx
 * @param {pc.AppBase} ctx.app
 * @param {object} ctx.arcade
 * @param {object} ctx.butterfly
 * @param {object} ctx.timeMachine
 * @param {object} ctx.audio
 * @param {object} ctx.paradox
 * @param {object} ctx.sceneRefs
 * @param {Function} ctx.updateButterflyHUD
 * @param {object} ctx.keypad
 * @param {pc.Entity} ctx.vehicle
 * @param {pc.Entity} ctx.ground
 */
export async function initExtensions(ctx) {
  const {
    app, arcade, butterfly, timeMachine, audio, paradox,
    sceneRefs, updateButterflyHUD, keypad, vehicle, ground
  } = ctx;

  // --- iOS / Touch module (replaces inline touch if desired) ---
  const touch = new TouchControls({
    onKeypad: () => { keypad.toggle(); audio.unlock(); }
  });
  // Bridge into vehicle each frame
  const prevUpdate = arcade.update.bind(arcade);
  arcade.update = function (dt) {
    const s = touch.getState();
    // Pre-seed input before internal read merges keys
    if (Math.abs(s.steer) > 0.05) this.input.steer = s.steer;
    if (Math.abs(s.throttle) > 0.05) this.input.throttle = s.throttle;
    if (s.handbrake) this.input.handbrake = true;
    if (s.boost) this.input.boost = true;
    prevUpdate(dt);
  };

  // --- Flag panel ---
  const flagPanel = new FlagPanel(butterfly, () => {
    butterfly.evaluateAndMutateAssets(timeMachine.getCurrentEra(), sceneRefs);
    updateButterflyHUD();
    saveNow();
  });

  // --- Save / Load ---
  const save = new SaveStateCompressor();
  function saveNow() {
    save.save({
      flagMask: butterfly.toBitmask(),
      era: timeMachine.getCurrentEra()
    });
  }
  const loaded = save.load();
  if (loaded) {
    butterfly.fromBitmask(loaded.flagMask);
    butterfly.evaluateAndMutateAssets(timeMachine.getCurrentEra(), sceneRefs);
    updateButterflyHUD();
    console.log('[Save] Restored flags from LocalStorage');
  }
  // Autosave on era change — hook via existing callback is left to main;
  // expose saveNow for callers
  setInterval(saveNow, 15000);

  // --- Proximity triggers ---
  const triggers = new ButterflyTriggers(butterfly);
  triggers.addZone({ id: 'pine_hit', center: { x: -14, y: 0, z: 16 }, radius: 3.5, flag: 'pine_tree_destroyed_1885', eraRequired: '1885' });
  triggers.addZone({ id: 'clock_strike', center: { x: 0, y: 0, z: -12 }, radius: 5, flag: 'courthouse_clock_stopped_1955', eraRequired: '1955' });
  triggers.addZone({ id: 'lab_raid', center: { x: 24, y: 0, z: -18 }, radius: 6, flag: 'doc_lab_raided_1985', eraRequired: '1985' });

  // --- AI ---
  const chase = new ChasePhysicsController(app);
  const pathfinder = new TemporalPathfinder();
  pathfinder.setEra(timeMachine.getCurrentEra());

  // --- Audio beds ---
  let radio = null;
  let ambient = null;
  if (audio.ctx) {
    radio = new RadioManager(audio.ctx, audio.masterGain);
    ambient = new AmbientBed(audio.ctx, audio.masterGain);
    radio.setEra(timeMachine.getCurrentEra());
    ambient.setEra(timeMachine.getCurrentEra());
  }

  // --- Asset loader (ready for real glTF URLs) ---
  const loader = new AssetPipelineLoader(app, {
    onProgress: (done, total, id) => {
      const el = document.getElementById('status-bar');
      if (el) el.textContent = `Loading ${id} (${done}/${total})`;
    },
    onComplete: () => {
      const el = document.getElementById('status-bar');
      if (el) el.textContent = 'Hill Valley · Assets ready';
    }
  });
  // --- Real public-domain glTF models (Khronos Sample Models via jsDelivr) ---
  // CesiumMilkTruck → parked near mall (1985 era root if available)
  const era1985 = app.root.findByName('Era_1985') || app.root;
  const era1955 = app.root.findByName('Era_1955') || app.root;

  loader.enqueue({
    id: 'cesium_milk_truck',
    url: 'https://cdn.jsdelivr.net/gh/KhronosGroup/glTF-Sample-Models@master/2.0/CesiumMilkTruck/glTF-Binary/CesiumMilkTruck.glb',
    type: 'container',
    era: '1985',
    parent: era1985,
    onLoaded: (result) => {
      if (result.entity) {
        result.entity.setLocalPosition(22, 0, 32);
        result.entity.setLocalScale(1.8, 1.8, 1.8);
        result.entity.setLocalEulerAngles(0, -40, 0);
        console.log('[Loader] CesiumMilkTruck instantiated under', era1985.name);
      }
    }
  });

  // Duck → near diner as a quirky landmark (always visible under root)
  loader.enqueue({
    id: 'khronos_duck',
    url: 'https://cdn.jsdelivr.net/gh/KhronosGroup/glTF-Sample-Models@master/2.0/Duck/glTF-Binary/Duck.glb',
    type: 'container',
    era: '1955',
    parent: app.root,
    onLoaded: (result) => {
      if (result.entity) {
        result.entity.setLocalPosition(-20, 0.5, 12);
        result.entity.setLocalScale(1.2, 1.2, 1.2);
        console.log('[Loader] Duck instantiated near diner');
      }
    }
  });

  // DamagedHelmet → Doc lab prop
  loader.enqueue({
    id: 'damaged_helmet',
    url: 'https://cdn.jsdelivr.net/gh/KhronosGroup/glTF-Sample-Models@master/2.0/DamagedHelmet/glTF-Binary/DamagedHelmet.glb',
    type: 'container',
    era: '1985',
    parent: app.root,
    onLoaded: (result) => {
      if (result.entity) {
        result.entity.setLocalPosition(24, 1.2, -15);
        result.entity.setLocalScale(0.35, 0.35, 0.35);
        console.log('[Loader] DamagedHelmet in Doc lab area');
      }
    }
  });

  // --- Ammo (optional) ---
  const physicsOk = await bootstrapAmmo();
  if (physicsOk && ground) {
    makeStaticCollider(ground, new pc.Vec3(55, 0.2, 55));
    console.log('[Physics] Ground collider enabled');
  }

  // --- Per-frame extension tick ---
  app.on('update', (dt) => {
    const pos = vehicle.getPosition();
    triggers.update(pos, timeMachine.getCurrentEra());

    const stars = paradox.getStars();
    pathfinder.setPanic(stars >= 3);
    pathfinder.setEra(timeMachine.getCurrentEra());

    chase.syncChasers(stars, vehicle, () => {
      // Simple chaser mesh
      const c = new pc.Entity('Chaser');
      c.addComponent('render', { type: 'box' });
      c.setLocalScale(2, 0.8, 4);
      const mat = new pc.StandardMaterial();
      mat.diffuse = new pc.Color(0.6, 0.1, 0.1);
      mat.update();
      c.render.meshInstances[0].material = mat;
      app.root.addChild(c);
      return c;
    });
    chase.update(dt, vehicle, arcade.getVelocity(), () => {
      // Ram: nudge player
      const v = arcade.getVelocity();
      arcade.setVelocity(v.x * 0.7 + (Math.random() - 0.5) * 8, v.y + 2, v.z * 0.7 + (Math.random() - 0.5) * 8);
    });
  });

  // Era-change audio beds — monkey-patch by wrapping is heavy; expose helper
  const onEra = (era) => {
    pathfinder.setEra(era);
    radio?.setEra(era);
    ambient?.setEra(era);
    saveNow();
  };

  console.log('[Extensions] Touch, FlagPanel, Save, Triggers, AI, Loader, Physics ready');
  return { touch, flagPanel, save, triggers, chase, pathfinder, loader, radio, ambient, physicsOk, onEra, saveNow };
}
