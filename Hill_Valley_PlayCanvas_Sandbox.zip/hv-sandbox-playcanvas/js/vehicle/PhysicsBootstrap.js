/**
 * PhysicsBootstrap — optional ammo.js (WASM) loader for PlayCanvas standalone.
 * Falls back gracefully if WASM fails (keeps plane suspension).
 */

import * as pc from 'playcanvas';

const AMMO_CONFIG = {
  glueUrl: 'https://developer.playcanvas.com/assets/modules/ammo/ammo.wasm.js',
  wasmUrl: 'https://developer.playcanvas.com/assets/modules/ammo/ammo.wasm.wasm',
  fallbackUrl: 'https://developer.playcanvas.com/assets/modules/ammo/ammo.js'
};

/**
 * Attempt to load Ammo WASM and enable rigidbody system.
 * @returns {Promise<boolean>} true if physics is ready
 */
export async function bootstrapAmmo() {
  if (!pc.WasmModule) {
    console.warn('[Physics] WasmModule API not available in this engine build');
    return false;
  }

  try {
    pc.WasmModule.setConfig('Ammo', AMMO_CONFIG);
    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('Ammo load timeout')), 15000);
      pc.WasmModule.getInstance('Ammo', () => {
        clearTimeout(timeout);
        resolve();
      });
    });
    console.log('[Physics] Ammo.js WASM ready');
    return true;
  } catch (e) {
    console.warn('[Physics] Ammo load failed — continuing with plane suspension', e);
    return false;
  }
}

/**
 * Add static rigidbody + box collision to an entity (ground, buildings).
 * Safe no-op if rigidbody system is missing.
 */
export function makeStaticCollider(entity, halfExtents) {
  if (!entity || !entity.addComponent) return;
  try {
    if (!entity.collision) {
      entity.addComponent('collision', {
        type: 'box',
        halfExtents: halfExtents || new pc.Vec3(1, 1, 1)
      });
    }
    if (!entity.rigidbody) {
      entity.addComponent('rigidbody', { type: 'static' });
    }
  } catch (e) {
    // System not registered — ignore
  }
}

/**
 * 4-point raycast suspension helper using rigidbody system.
 * @param {pc.AppBase} app
 * @param {pc.Entity} vehicleEntity
 * @param {pc.Vec3[]} localWheelPoints - offsets from vehicle origin
 * @param {number} rayLength
 * @returns {{ onGround: boolean, points: Array<{hit:boolean, point:pc.Vec3, normal:pc.Vec3, dist:number}> }}
 */
export function raycastWheels(app, vehicleEntity, localWheelPoints, rayLength = 1.2) {
  const result = { onGround: false, points: [] };
  if (!app.systems?.rigidbody?.raycastFirst) {
    return result;
  }

  const worldPos = vehicleEntity.getPosition();
  const worldTransform = vehicleEntity.getWorldTransform();

  for (const local of localWheelPoints) {
    const start = new pc.Vec3();
    worldTransform.transformPoint(local, start);
    // Raise start slightly
    start.y += 0.15;
    const end = start.clone();
    end.y -= rayLength;

    const hit = app.systems.rigidbody.raycastFirst(start, end);
    if (hit) {
      result.onGround = true;
      result.points.push({
        hit: true,
        point: hit.point.clone(),
        normal: hit.normal ? hit.normal.clone() : pc.Vec3.UP.clone(),
        dist: start.y - hit.point.y
      });
    } else {
      result.points.push({ hit: false, point: end, normal: pc.Vec3.UP.clone(), dist: rayLength });
    }
  }
  return result;
}
