/**
 * RaycastArcadeController — Vice City style arcade vehicle for PlayCanvas
 * Kinematic / velocity-based with suspension feel.
 * Plane-based ground for prototype (no ammo.js required).
 * Swap in app.systems.rigidbody.raycastFirst when physics module is loaded.
 */

import * as pc from 'playcanvas';

export class RaycastArcadeController {
  /**
   * @param {pc.Entity} entity
   * @param {pc.AppBase} app
   * @param {object} options
   */
  constructor(entity, app, options = {}) {
    this.entity = entity;
    this.app = app;

    this.config = {
      maxSpeed: 55,                 // m/s ≈ 123 mph
      acceleration: 28,
      reverseAccel: 18,
      turnSpeed: 2.4,
      turnSpeedHigh: 1.1,
      drag: 0.55,
      lateralFriction: 9.0,
      driftLateralFriction: 1.15,
      suspensionRest: 0.55,
      suspensionStiffness: 38,
      suspensionDamping: 7.0,
      gravity: 18,
      hoverHeight: 1.9,
      hoverStiffness: 24,
      hoverDamping: 5.5,
      boostMultiplier: 1.55,
      ...options
    };

    this.velocity = new pc.Vec3();
    this.angularVelocity = 0;
    this.speedMPH = 0;
    this.onGround = false;
    this.hoverMode = false;
    this.groundY = 0;
    this.hoverAllowed = false;

    this.input = {
      throttle: 0,
      steer: 0,
      handbrake: false,
      boost: false
    };

    this._keys = {};
    this._prevH = false;
    this._setupInput();

    this._tmp = new pc.Vec3();
    this._forward = new pc.Vec3();
    this._right = new pc.Vec3();
  }

  _setupInput() {
    const onKey = (e, down) => {
      this._keys[e.code] = down;
      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(e.code)) {
        e.preventDefault();
      }
    };
    window.addEventListener('keydown', e => onKey(e, true));
    window.addEventListener('keyup', e => onKey(e, false));
  }

  _readInput() {
    const k = this._keys;
    this.input.throttle = 0;
    this.input.steer = 0;

    if (k['KeyW'] || k['ArrowUp']) this.input.throttle += 1;
    if (k['KeyS'] || k['ArrowDown']) this.input.throttle -= 1;
    if (k['KeyA'] || k['ArrowLeft']) this.input.steer += 1;
    if (k['KeyD'] || k['ArrowRight']) this.input.steer -= 1;

    this.input.handbrake = !!k['Space'];
    this.input.boost = !!(k['ShiftLeft'] || k['ShiftRight']);

    if (k['KeyH'] && !this._prevH && this.hoverAllowed) {
      this.hoverMode = !this.hoverMode;
    }
    this._prevH = !!k['KeyH'];
  }

  update(dt) {
    this._readInput();

    const pos = this.entity.getPosition();
    const config = this.config;

    this._forward.copy(this.entity.forward);
    this._right.cross(pc.Vec3.UP, this._forward).normalize();

    // --- Ground (plane-based prototype) ---
    const groundPlaneY = 0.0;
    const vehicleHalfHeight = 0.45;
    const restHeight = groundPlaneY + vehicleHalfHeight + config.suspensionRest;

    this.onGround = false;
    let suspensionForce = 0;

    const heightAboveRest = pos.y - restHeight;
    if (heightAboveRest < 1.2) {
      this.onGround = true;
      this.groundY = groundPlaneY;
      const compression = -heightAboveRest;
      const spring = compression * config.suspensionStiffness;
      const damper = -this.velocity.y * config.suspensionDamping;
      suspensionForce = spring + damper;
    }

    // --- Acceleration ---
    let accel = 0;
    if (this.input.throttle > 0) {
      accel = config.acceleration * this.input.throttle;
      if (this.input.boost) accel *= config.boostMultiplier;
    } else if (this.input.throttle < 0) {
      accel = config.reverseAccel * this.input.throttle;
    }

    this._tmp.copy(this._forward).mulScalar(accel * dt);
    this.velocity.add(this._tmp);

    // --- Lateral friction / drift ---
    const lateralFriction = this.input.handbrake
      ? config.driftLateralFriction
      : config.lateralFriction;

    const lateralSpeed = this.velocity.dot(this._right);
    this._tmp.copy(this._right).mulScalar(-lateralSpeed * Math.min(1, lateralFriction * dt));
    this.velocity.add(this._tmp);

    // Drag
    this.velocity.x *= (1 - config.drag * dt);
    this.velocity.z *= (1 - config.drag * dt);

    // Gravity / Hover
    if (this.hoverMode && this.hoverAllowed) {
      const targetY = this.groundY + config.hoverHeight;
      const error = targetY - pos.y;
      const hoverForce = error * config.hoverStiffness - this.velocity.y * config.hoverDamping;
      this.velocity.y += hoverForce * dt;
      if (pos.y > this.groundY + config.hoverHeight * 2.4) {
        this.velocity.y -= 12 * dt;
      }
    } else {
      this.velocity.y -= config.gravity * dt;
      if (this.onGround) {
        this.velocity.y += suspensionForce * dt;
        if (pos.y < restHeight - 0.15 && this.velocity.y < 0) {
          this.velocity.y = Math.max(this.velocity.y, 0);
          // Soft snap
          this.entity.setPosition(pos.x, Math.max(pos.y, restHeight - 0.3), pos.z);
        }
      }
    }

    // Clamp horizontal speed
    const horizontal = new pc.Vec3(this.velocity.x, 0, this.velocity.z);
    const speed = horizontal.length();
    if (speed > config.maxSpeed) {
      horizontal.normalize().mulScalar(config.maxSpeed);
      this.velocity.x = horizontal.x;
      this.velocity.z = horizontal.z;
    }

    // Steering
    const speedFactor = Math.min(1, speed / 12);
    const turnRate = pc.math.lerp(config.turnSpeed, config.turnSpeedHigh, speedFactor);
    if (Math.abs(this.input.throttle) > 0.1 || speed > 1.2) {
      this.angularVelocity = this.input.steer * turnRate * (this.input.throttle < 0 ? -1 : 1);
    } else {
      this.angularVelocity *= 0.82;
    }

    // Integrate position
    this._tmp.copy(this.velocity).mulScalar(dt);
    const newPos = this.entity.getPosition();
    this.entity.setPosition(
      newPos.x + this._tmp.x,
      newPos.y + this._tmp.y,
      newPos.z + this._tmp.z
    );

    if (Math.abs(this.angularVelocity) > 0.001) {
      this.entity.rotate(0, this.angularVelocity * dt * pc.math.RAD_TO_DEG, 0);
    }

    this.speedMPH = speed * 2.2369;
  }

  setVelocity(x, y, z) {
    this.velocity.set(x, y, z);
  }

  getVelocity() {
    return this.velocity.clone();
  }

  setHoverAllowed(allowed) {
    this.hoverAllowed = !!allowed;
    if (!allowed) this.hoverMode = false;
  }
}
