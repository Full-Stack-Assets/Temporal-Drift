# Hill Valley Multi-Era Sandbox — PlayCanvas

Full base map · Characters · 7+ butterfly flags · AI · Loader · Mobile PWA · Slice plans 3–10

## Run

```bash
cd hv-sandbox-playcanvas
python3 -m http.server 8080
```

Open http://localhost:8080 — on iPhone use Safari → Add to Home Screen.

## New modules (this pass)

| Path | Role |
|------|------|
| `js/loader/AssetPipelineLoader.js` | Sequential glTF/JSON loader with retries |
| `js/vehicle/PhysicsBootstrap.js` | Optional Ammo WASM bootstrap + wheel raycast helper |
| `js/ai/ChasePhysicsController.js` | Predictive intercept chases |
| `js/ai/TemporalPathfinder.js` | Era archetypes + waypoints |
| `js/audio/RadioManager.js` | Era station beds |
| `js/audio/AmbientBed.js` | Wind/town noise beds |
| `js/ui/TouchControls.js` | iOS-aware pointer/touch stick + buttons |
| `js/ui/FlagPanel.js` | On-screen flag toggles |
| `js/storage/SaveStateCompressor.js` | LocalStorage bitmask save |
| `js/temporal/ButterflyTriggers.js` | Proximity flag triggers |
| `SLICES_3_TO_10.md` | Exhaustive plans for slices 3–10 |
| `MOBILE_NOTES.md` | Three.js-inspired mobile optimization notes |

## Controls

- **WASD** drive · **Space** handbrake · **Shift** boost · **H** hover (2015/2045)
- **Tab** keypad · **P / 1–7** butterfly flags
- **Touch**: stick + GAS/BRAKE/HB/BOOST/TIME
- Flag panel buttons (left side) on all devices

## Ammo.js

`PhysicsBootstrap.bootstrapAmmo()` loads WASM from PlayCanvas CDN.  
If it fails (CORS/offline), plane suspension continues.  
Wire into `main.js` before enabling rigidbody colliders (Slice 3 task).

## glTF pipeline

```js
import { AssetPipelineLoader } from './loader/AssetPipelineLoader.js';
const loader = new AssetPipelineLoader(app, {
  onProgress: (done, total, id) => console.log(done, total, id)
});
loader.enqueue({
  id: 'courthouse',
  url: 'https://example.com/courthouse.glb',
  type: 'container',
  parent: eraRoots['1985']
});
```

## Slices

See `SLICES_3_TO_10.md` for detailed goals, deliverables, tasks, risks, and exit gates.
